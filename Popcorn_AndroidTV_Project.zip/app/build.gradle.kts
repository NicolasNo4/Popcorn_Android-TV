plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.popcorn.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.popcorn.tv"
        minSdk = 21
        targetSdk = 34
        versionCode = 100
        versionName = "1.0.0"
    }

    signingConfigs {
        create("release") {
            storeFile = file("keystore/popcorn-release-key.jks")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "Popcorn2026!"
            keyAlias = System.getenv("KEY_ALIAS") ?: "popcorn_tv"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "Popcorn2026!"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.webkit:webkit:1.11.0")

    // Media3 ExoPlayer 核心 + HLS(M3U8直播) + DASH + 杜比直通支持
    val media3Version = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("androidx.media3:media3-session:$media3Version")

    // 网络请求与后台定时巡检 (每日检测电视台直播源存活状态 & TMDB 刮削)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
}

package com.popcorn.tv.cloud

import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

enum class DriveProtocol {
    WEBDAV, ALIST, ALIYUN_OPEN, BAIDU_NETDISK, DRIVE_115, SMB_NAS
}

data class MountedDrive(
    val id: String,
    val name: String,
    val protocol: DriveProtocol,
    val endpointUrl: String,
    val username: String,
    val rootPath: String = "/"
)

data class CloudMediaFile(
    val name: String,
    val streamUrl: String
)

class CloudDriveMountManager {
    private val client = OkHttpClient()
    private val videoExtensions = setOf("mkv", "mp4", "ts", "iso", "m2ts", "mov", "avi")

    fun scanWebDavOrAlistDirectory(drive: MountedDrive, password: String): List<CloudMediaFile> {
        val fullUrl = drive.endpointUrl.trimEnd('/') + "/" + drive.rootPath.trimStart('/')
        val propfindXml = """<?xml version="1.0" encoding="utf-8" ?><D:propfind xmlns:D="DAV:"><D:allprop/></D:propfind>"""
        val req = Request.Builder()
            .url(fullUrl)
            .method("PROPFIND", propfindXml.toRequestBody("application/xml".toMediaType()))
            .header("Authorization", Credentials.basic(drive.username, password))
            .header("Depth", "1")
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                Regex("<D:href>(.*?)</D:href>").findAll(body)
                    .map { it.groupValues[1] }
                    .filter { path -> videoExtensions.contains(path.substringAfterLast('.', "").lowercase()) }
                    .map { path ->
                        val fileName = path.trimEnd('/').substringAfterLast('/')
                        CloudMediaFile(fileName, drive.endpointUrl.trimEnd('/') + path)
                    }.toList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

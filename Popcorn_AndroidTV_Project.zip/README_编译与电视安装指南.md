# Popcorn (爆米花 TV) - 安卓电视端工程与一键打包签名指南

本工程已完整集成您提供的 **Popcorn 专属流金图标 (`ic_launcher.png` 与 Android TV 桌面横幅 `tv_banner.png`)**，并已预生成正式版 V1+V2+V3 签名证书 (`app/keystore/popcorn-release-key.jks`)，适配 Sony、TCL、海信、小米、雷鸟、当贝、极米及各类 Android 5.0 ~ 14 电视与机顶盒。

## 核心特性
1. **Apple TV (tvOS) 流体毛玻璃界面**：顶栏胶囊悬浮毛玻璃导航 (`backdrop-filter` / RenderEffect 高斯模糊)、遥控器焦点 3D 缩放光晕与全屏海报背景联动。
2. **媲美网易爆米花 & Infuse 的网盘挂载与精准刮削**：支持 WebDAV、Alist、阿里云盘、百度网盘、115 网盘与局域网 SMB/NAS 一键挂载；自动清洗压制组/分辨率噪点并匹配 TMDB 中文海报墙、演职员与评分。
3. **国内地方电视台 + 每日自动巡检换源**：涵盖央视、各大卫视及浙江/广东/江苏等地方台，内置 `LiveTvHealthWorker` 每日自动测试 M3U8 延迟与有效性，失效直播源自动切换至备用源。
4. **Netflix 风格网络影视仓**：内置每日最热 Top 10、亚洲区电影排行、美剧排行，支持多线路接口聚合、分类检索与首字母搜索。
5. **杜比视界 & 杜比全景声播放器**：基于 Media3 ExoPlayer + FFmpeg 解码扩展，支持 Dolby Vision / Dolby Atmos 直通、多音轨无缝切换（国语/原声/粤语）及在线字幕实时搜索挂载。

## 两种方式快速获取可插 U 盘安装的 `.apk` 文件

### 方式一：GitHub 云端免环境一键打包（推荐，无需本地安装 Android Studio）
1. 将本压缩包解压后上传至您的任意 GitHub 仓库（私有或公开均可）。
2. 点击仓库顶部的 **Actions** -> **Build Signed Popcorn Android TV APK** -> **Run workflow**。
3. 约 2 分钟后编译完成，直接下载生成的 `Popcorn-TV-v1.0.0-Signed-APK` 即可拷入 U 盘插到电视上安装。

### 方式二：本地 Android Studio 一键生成
1. 使用 Android Studio 打开本工程目录。
2. 直接点击菜单栏 **Build -> Generate Signed Bundle / APK**（签名密钥已内置于 `app/keystore/popcorn-release-key.jks`，密码 `Popcorn2026!`，别名 `popcorn_tv`，无需手动配置直接运行 `gradlew assembleRelease` 即可）。
3. 在 `app/build/outputs/apk/release/app-release.apk` 获取已签名安装包。
